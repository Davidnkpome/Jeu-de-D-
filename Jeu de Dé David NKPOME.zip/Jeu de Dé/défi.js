/*
- Le jeu comporte 2 joueurs, jouant à tour de rôle.
- À chaque tour, un joueur lance un dé autant de fois qu'il le souhaite. Chaque résultat est ajouté à son score de tour (ROUND).
- Cependant, si le joueur lance un 1, il perd tout son score de tour. Ensuite, c'est au tour du joueur suivant.
- Le joueur peut choisir de "Conserver", ce qui signifie que son score de tour est ajouté à son score global (GLOBAL). C'est ensuite au tour du joueur suivant.
- Le premier joueur à atteindre 100 points sur son score global remporte la partie.
*/

/*
1. Un joueur perd tout son score s'il lance deux 6 consécutifs. Après cela, c'est au tour du joueur suivant.
2. Ajouter un champ de saisie dans le HTML où les joueurs peuvent définir le score gagnant, permettant de changer le score prédéfini de 100.
3. Ajouter un autre dé au jeu, ce qui signifie qu'il y a maintenant deux dés. Le joueur perd son score actuel si l'un d'eux montre un 1.
*/


// Déclaration des variables fondamentales du jeu
var scores, roundScore, activePlayer, prevDiceRoll, gamePlaying;

// Initialisation du jeu
init();

// Ajout d'un écouteur d'événements au bouton qui lance les dés
document.querySelector('.btn-roll').addEventListener('click', function() {
  if (gamePlaying) {
    // Créer deux nombres aléatoires pour les dés
    var dice1 = Math.floor(Math.random() * 6) + 1;
    var dice2 = Math.floor(Math.random() * 6) + 1;

    // Afficher les résultats
    document.getElementById('dice1').style.display = 'block';
    document.getElementById('dice2').style.display = 'block';
    document.getElementById('dice1').src = 'dice-' + dice1 + '.png';
    document.getElementById('dice2').src = 'dice-' + dice2 + '.png';
    
    // Vérifier si le joueur lance deux 6 consécutifs
    if (dice1 === 6 && prevDiceRoll === 6) {
        // Le joueur perd tout son score
        scores[activePlayer] = 0;
        document.querySelector('#score-' + activePlayer).textContent = '0';
        nextPlayer();
    } else if (dice1 !== 1 && dice2 !== 1) {
        // Ajouter le score si le nombre obtenu est différent de 1
        roundScore += dice1 + dice2;
        document.querySelector('#current-' + activePlayer).textContent = roundScore;
    } else {
        // Passage au joueur suivant  
        nextPlayer();
    }

    // Sauvegarder le dernier lancer de dé
    prevDiceRoll = dice1;
  }
});

// Fonctionnalité permettant d'accumuler des points ("Conserver")
document.querySelector('.btn-hold').addEventListener('click', function() {
  if (gamePlaying) {
    // Ajouter le score actuel au score global
    scores[activePlayer] += roundScore;

    // Mise à jour de l'interface utilisateur
    document.querySelector('#score-' + activePlayer).textContent = scores[activePlayer];

    // Vérifier si le joueur a atteint le score gagnant
    var input = document.getElementById('winningScore').value;
    var winningScore;
    if (input) {
      winningScore = input;
    } else {
      winningScore = 100;
    }

    if (scores[activePlayer] >= winningScore) {
      // Changer le nom du joueur en "Gagnant !"
      document.querySelector('#name-' + activePlayer).textContent = 'Gagnant !';
      document.getElementById('dice1').style.display = 'none';
      document.getElementById('dice2').style.display = 'none';
      document.querySelector('.player-' + activePlayer + '-panel').classList.add('winner');
      document.querySelector('.player-' + activePlayer + '-panel').classList.remove('active');
      gamePlaying = false;
    } else {
      nextPlayer();
    }
  }
});

// Redémarrage du jeu après un clic sur le bouton "Nouvelle Partie"
document.querySelector('.btn-new').addEventListener('click', init);

// Fonction d'initialisation du jeu
function init() {
  gamePlaying = true;
  scores = [0, 0];
  activePlayer = 0;
  roundScore = 0;
  document.getElementById('dice1').style.display = 'none';
  document.getElementById('dice2').style.display = 'none';
  document.getElementById('score-0').textContent = '0';
  document.getElementById('score-1').textContent = '0';
  document.getElementById('current-0').textContent = '0';
  document.getElementById('current-1').textContent = '0';
  document.getElementById('name-0').textContent = 'Joueur 1';
  document.getElementById('name-1').textContent = 'Joueur 2';
  document.querySelector('.player-0-panel').classList.remove('winner');
  document.querySelector('.player-1-panel').classList.remove('winner');
  document.querySelector('.player-0-panel').classList.remove('active');
  document.querySelector('.player-1-panel').classList.remove('active');
  document.querySelector('.player-0-panel').classList.add('active');
}

// Fonction pour passer le tour au joueur suivant
function nextPlayer() {
  activePlayer = activePlayer === 0 ? 1 : 0;
  roundScore = 0;
  document.getElementById('current-0').textContent = '0';
  document.getElementById('current-1').textContent = '0';
  document.querySelector('.player-0-panel').classList.toggle('active');
  document.querySelector('.player-1-panel').classList.toggle('active');
  document.getElementById('dice1').style.display = 'none';
  document.getElementById('dice2').style.display = 'none';
}
