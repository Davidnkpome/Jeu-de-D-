/**************/
/* RÈGLES DU JEU */
/**************/

/*
- Le jeu comporte 2 joueurs, jouant à tour de rôle.
- À chaque tour, un joueur lance un dé autant de fois qu'il le souhaite. Chaque résultat est ajouté à son score de tour (ROUND).
- Si le joueur obtient un 1, il perd tout son score de tour. Ensuite, c'est au tour du joueur suivant.
- Un joueur peut choisir de "Conserver" son score, ce qui signifie que son score de tour est ajouté à son score global (GLOBAL). C'est ensuite au tour du joueur suivant.
- Le premier joueur à atteindre 100 points sur son score global remporte la partie.
*/

/*****************/
/* CODE DU JEU */
/*****************/

// Déclaration des variables fondamentales pour le jeu
var scores, roundScore, activePlayer, gamePlaying;

// Initialisation du jeu
init();

/*
Ajout d'un écouteur d'événements au bouton de lancer de dé.
Cela permet au bouton de réagir au clic et d'exécuter une fonction.
*/
document.querySelector('.btn-roll').addEventListener('click', function() {
    // Vérifie si le jeu est en cours
    if (gamePlaying) {
        // Création d'un nombre aléatoire pour le dé
        var dice = Math.floor(Math.random() * 6) + 1;

        // Affichage du résultat du dé
        var diceDOM = document.querySelector('.dice');
        diceDOM.style.display = 'block';
        diceDOM.src = 'dice-' + dice + '.png';

        // Mise à jour du score de tour si le dé ne montre pas 1
        if (dice !== 1) {
            // Ajoute le score si le dé n'est pas 1
            roundScore += dice;
            document.querySelector('#current-' + activePlayer).textContent = roundScore;
        } else {
            // Passage au joueur suivant si le dé est 1
            nextPlayer();
        }
    }
});

/*
Ajout d'un écouteur d'événements au bouton "Conserver".
Cela permet au joueur de conserver son score de tour et de l'ajouter à son score global.
*/
document.querySelector('.btn-hold').addEventListener('click', function() {
    if (gamePlaying) {
        // Ajout du score de tour au score global
        scores[activePlayer] += roundScore;

        // Mise à jour de l'interface utilisateur avec le nouveau score
        document.querySelector('#score-' + activePlayer).textContent = scores[activePlayer];

        // Vérification si le joueur a atteint 100 points et a gagné
        if (scores[activePlayer] >= 100) {
            // Affichage du statut de gagnant
            document.querySelector('#name-' + activePlayer).textContent = 'Gagnant !';
            document.querySelector('.dice').style.display = 'none';
            document.querySelector('.player-' + activePlayer + '-panel').classList.add('winner');
            document.querySelector('.player-' + activePlayer + '-panel').classList.remove('active');
            // Fin du jeu
            gamePlaying = false;
        } else {
            // Passage au joueur suivant
            nextPlayer();
        }
    }
});

/*
Redémarrage du jeu après un clic sur le bouton "Nouvelle partie".
La fonction init() réinitialise le jeu à son état initial.
*/
document.querySelector('.btn-new').addEventListener('click', init);

// Fonction pour initialiser le jeu
function init() {
    // Réinitialisation des scores et de l'état du jeu
    scores = [0, 0];
    activePlayer = 0;
    roundScore = 0;
    gamePlaying = true;

    // Masquage des dés au début du jeu
    document.querySelector('.dice').style.display = 'none';

    // Réinitialisation des scores affichés à 0
    document.getElementById('score-0').textContent = '0';
    document.getElementById('score-1').textContent = '0';
    document.getElementById('current-0').textContent = '0';
    document.getElementById('current-1').textContent = '0';

    // Réinitialisation des noms des joueurs et suppression des classes de gagnant et actif
    document.getElementById('name-0').textContent = 'Joueur 1';
    document.getElementById('name-1').textContent = 'Joueur 2';
    document.querySelector('.player-0-panel').classList.remove('winner');
    document.querySelector('.player-1-panel').classList.remove('winner');
    document.querySelector('.player-0-panel').classList.remove('active');
    document.querySelector('.player-1-panel').classList.remove('active');
    document.querySelector('.player-0-panel').classList.add('active');
}

// Fonction pour passer le tour au joueur suivant
function nextPlayer() {
    // Changement du joueur actif
    activePlayer = activePlayer === 0 ? 1 : 0;
    roundScore = 0;

    // Réinitialisation des scores de tour à 0
    document.getElementById('current-0').textContent = '0';
    document.getElementById('current-1').textContent = '0';

    // Alternance de la classe active pour indiquer le joueur actif
    document.querySelector('.player-0-panel').classList.toggle('active');
    document.querySelector('.player-1-panel').classList.toggle('active');

    // Masquage du dé après le changement de joueur
    document.querySelector('.dice').style.display = 'none';
}
